package com.user_management.config;

public class AuthenticationException extends RuntimeException {
	
	private static final long serialVersionUID = 1820275974120570180L;

	public AuthenticationException(String message, Throwable cause) {
		super(message, cause);
	}
}
