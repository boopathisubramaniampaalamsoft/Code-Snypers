package com.user_management.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.user_management.DTO.UserDTO;
import com.user_management.service.JwtUserDetailsService;

@RestController
@CrossOrigin(origins = { "http://localhost:3000", "http://localhost:4200", "chrome-extension://fhbjgbiflinjbdggehcddcbncdddomop" })
@RequestMapping("/api/usermanagement/")
public class UserController {

	@Autowired
	private JwtUserDetailsService jwtInMemoryUserDetailsService;

	@RequestMapping(value = "/userprofile", method = RequestMethod.GET)
	public ResponseEntity<?> getUserProfile(Principal principal) {

		UserDTO userVO = jwtInMemoryUserDetailsService.loadDTOUserByUsername(principal.getName());
		return ResponseEntity.ok(userVO);
	}

	@RequestMapping(value = "/updateprofile", method = RequestMethod.POST)
	public ResponseEntity<?> updateUserProfile(@RequestBody UserDTO userVO) {
		UserDTO userDTO = jwtInMemoryUserDetailsService.update(userVO);
		return ResponseEntity.ok(userDTO);
	}
	
	@DeleteMapping(value = "/deleteprofile/{id}")
	public ResponseEntity<?> deleteUserProfile(@PathVariable int id) {
		jwtInMemoryUserDetailsService.delete(id);
		return ResponseEntity.ok("User Profile Deleted");
	}

}
