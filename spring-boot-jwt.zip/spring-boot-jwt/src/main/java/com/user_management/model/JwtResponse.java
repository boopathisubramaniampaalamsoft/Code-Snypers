package com.user_management.model;

import java.io.Serializable;

import com.user_management.DTO.UserDTO;

public class JwtResponse implements Serializable {

	private static final long serialVersionUID = -8091879091924046844L;
	private final String jwttoken;
	private final UserDTO userDTO;

	public JwtResponse(String jwttoken, UserDTO userDTO) {
		this.jwttoken = jwttoken;
		this.userDTO = userDTO;
	}

	public String getToken() {
		return this.jwttoken;
	}

	public UserDTO getUserDTO() {
		return this.userDTO;
	}
}