package com.user_management.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.user_management.model.DAOUser;

@Repository
public interface UserRepository extends JpaRepository<DAOUser, Long> {

	Optional<DAOUser> findByUsername(String username);

	Optional<DAOUser> findById(long id);

}