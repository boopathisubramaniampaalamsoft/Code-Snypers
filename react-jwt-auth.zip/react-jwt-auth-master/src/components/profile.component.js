import React, { Component } from "react";
import { Link } from "react-router-dom";
import { Redirect } from "react-router-dom";

import AuthService from "../services/auth.service";
import UserService from "../services/user.service";

import EventBus from "../common/EventBus";

export default class Profile extends Component {
  constructor(props) {
    super(props);
    const currentUser = AuthService.getCurrentUser();

    this.state = {
      id:currentUser.id,
      username: currentUser.username,
      role: currentUser.role,
      redirect: null,
      userReady: false,
      currentUser: { username: "" }
    };
  }

  componentDidMount() {

    EventBus.on("userProfileDelete", () => {
      this.userProfileDelete();
    });


    const currentUser = AuthService.getCurrentUser();

    if (!currentUser) this.setState({ redirect: "/home" });
    this.setState({ currentUser: currentUser, userReady: true })
  }

  componentWillUnmount() {
    EventBus.remove("userProfileDelete");
  }

  userProfileDelete() {
    UserService.deleteProfile().then(
      () => {
        
      },
      error => {
        this.setState({
          successful: false,
          message: "Failed to delete profile"
        });
      }
    )
    AuthService.logout();
    this.setState({
      showModeratorBoard: false,
      showAdminBoard: false,
      currentUser: undefined,
    });
  }

  render() {
    if (this.state.redirect) {
      return <Redirect to={this.state.redirect} />
    }

    const { currentUser } = this.state;

    return (
      <div className="col-md-12">

        <div className="container">
        
          <div>
            <header className="jumbotron">
              <h3>
                <strong>{currentUser.username}</strong> Profile
              </h3>
            </header>
          </div>
        </div>
        <div className="card card-container">
          <img
            src="//ssl.gstatic.com/accounts/ui/avatar_2x.png"
            alt="profile-img"
            className="profile-img-card"
          />

          <div>

            <div className="form-group">
              <label>Id</label>
              <label className="form-control">{this.state.id}</label>
            </div>

            <div className="form-group">
              <label>Name</label>
              <label className="form-control">{this.state.username}</label>
            </div>


            <div className="form-group">
              <label>Role</label>
              <label className="form-control">{this.state.role}</label>
            </div>



            <div className="form-group">
                <Link to={"/updateprofile"} className="btn btn-primary btn-block">
                  Update
                </Link>
                <a href="/login" className="btn btn-danger btn-block" onClick={this.userProfileDelete}>
                  Delete
                </a>
            </div>
          </div>
        </div>
      
      </div>
      
    );
  }
}
