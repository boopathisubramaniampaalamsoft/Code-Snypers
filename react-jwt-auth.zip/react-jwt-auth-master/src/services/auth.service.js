import axios from "axios";

const API_URL = "http://localhost:8080/api/usermanagement/";

class AuthService {
  login(username, password) {
    return axios
      .post(API_URL + "authenticate", {
        username,
        password
      })
      .then(response => {
        response.data.accessToken = response.data.token;
        response.data.user = response.data.userDTO.username;
        response.data.username = response.data.userDTO.username;
        response.data.id = response.data.userDTO.id;
        response.data.role = response.data.userDTO.role;
        if (response.data.accessToken) {
          localStorage.setItem("user", JSON.stringify(response.data));
        }

        return response.data;
      });
  }

  logout() {
    localStorage.removeItem("user");
  }

  register(username, role, password) {
    return axios.post(API_URL + "register", {
      username,
      role,
      password
    });
  }

  getCurrentUser() {
    return JSON.parse(localStorage.getItem('user'));;
  }
}

export default new AuthService();
