export default function authHeader() {
  const user = JSON.parse(localStorage.getItem('user'));

  if (user && user.accessToken) {
    return { authorization: 'Bearer ' + user.accessToken}//, 'Access-Control-Allow-Origin': 'http://localhost:3000', "Access-Control-Allow-Headers":"Origin, Accept, Content-Type, Authorization, Access-Control-Allow-Origin, X-Requested-With, remember-me, Access-Control-Allow-Methods", "Access-Control-Allow-Methods":"POST,GET,OPTIONS, PUT, DELETE", "cache-control": "no-cache" }; // for Spring Boot back-end
    //return { 'x-access-token': user.accessToken };       // for Node.js Express back-end
  } else {
    return {};
  }
}
