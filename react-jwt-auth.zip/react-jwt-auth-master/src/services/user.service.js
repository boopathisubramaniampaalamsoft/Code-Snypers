import axios from 'axios';

const API_URL = 'http://192.168.14.21:8080/api/usermanagement/';

class UserService {
  
  getUserProfile() {
    const user = JSON.parse(localStorage.getItem('user'));
    const token = user.token;
    return axios.get(API_URL + 'userprofile',
        { headers: { authorization: 'Bearer ' + token } }
    );
    
  }

  updateProfile(id, username, role, password) {
    const user = JSON.parse(localStorage.getItem('user'));
    const token = user.token;
     return axios.post(API_URL + "updateprofile", {
       id,
       username,
       role,
       password
     }, { headers: { authorization: 'Bearer ' + token }});
  }

  deleteProfile() {
    const user = JSON.parse(localStorage.getItem('user'));
    const token = user.token;
    const id = user.id;
    return axios.delete(API_URL + 'deleteprofile/'+id, { headers: { authorization: 'Bearer ' + token }});
  }
}

export default new UserService();
